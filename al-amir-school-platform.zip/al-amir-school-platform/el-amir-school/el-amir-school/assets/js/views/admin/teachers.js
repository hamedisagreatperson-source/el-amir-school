const AdminTeachers = (() => {
  async function render() {
    const page = document.getElementById('page-content');
    page.innerHTML = `
      <div class="flex items-center justify-between mb-20">
        <h2 style="font-size:1.1rem">قائمة الأساتذة</h2>
        <button class="btn btn-accent" onclick="AdminTeachers.showAddModal()">&#43; إضافة أستاذ</button>
      </div>
      <div id="teachers-container"><div style="padding:40px;text-align:center;color:var(--text-muted)">جاري التحميل...</div></div>
    `;
    await loadTeachers();
  }

  async function loadTeachers() {
    const container = document.getElementById('teachers-container');
    try {
      const data = await API.get('/admin/teachers');
      const teachers = data.teachers || [];
      if (teachers.length === 0) {
        container.innerHTML = '<div class="empty-state"><div class="icon">&#128105;&#8205;&#127979;</div><div class="title">لا يوجد أساتذة</div></div>';
        return;
      }
      container.innerHTML = `
        <div class="table-container">
          <table class="data-table">
            <thead><tr><th>الاسم</th><th>المادة</th><th>الهاتف</th><th>البريد</th><th>الحالة</th><th>الإجراءات</th></tr></thead>
            <tbody>
              ${teachers.map(t => `
                <tr>
                  <td style="font-weight:600">${Utils.escapeHtml(t.full_name)}</td>
                  <td>${t.subject || '—'}</td>
                  <td class="mono">${t.phone || '—'}</td>
                  <td>${t.email}</td>
                  <td>${t.is_active ? '<span class="badge badge-success">نشط</span>' : '<span class="badge badge-muted">معطّل</span>'}</td>
                  <td>
                    <div style="display:flex;gap:4px">
                      <button class="btn btn-ghost btn-sm" onclick="AdminTeachers.viewTeacher('${t.id}')" title="عرض">&#128065;</button>
                      <button class="btn btn-ghost btn-sm" onclick="AdminTeachers.editTeacher('${t.id}')" title="تعديل">&#9998;</button>
                      <button class="btn btn-ghost btn-sm" onclick="AdminTeachers.impersonate('${t.id}')" title="دخول كأستاذ" style="color:var(--warning)">&#128274;</button>
                      <button class="btn btn-ghost btn-sm" onclick="AdminTeachers.deleteTeacher('${t.id}')" title="حذف" style="color:var(--danger)">&#128465;</button>
                    </div>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    } catch (err) {
      container.innerHTML = `<div class="empty-state"><div class="title">خطأ: ${err.message}</div></div>`;
    }
  }

  function showAddModal() {
    const content = `
      <form id="add-teacher-form" onsubmit="AdminTeachers.submitAdd(event)">
        <div class="form-row">
          <div class="form-group"><label class="form-label">الاسم الكامل *</label><input type="text" class="form-input" name="full_name" required></div>
          <div class="form-group"><label class="form-label">المادة</label><input type="text" class="form-input" name="subject"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">البريد *</label><input type="email" class="form-input" name="email" required></div>
          <div class="form-group"><label class="form-label">الهاتف</label><input type="tel" class="form-input" name="phone"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">اسم المستخدم *</label><input type="text" class="form-input" name="username" required></div>
          <div class="form-group"><label class="form-label">كلمة المرور *</label><input type="password" class="form-input" name="password" required minlength="6"></div>
        </div>
        <div class="form-group"><label class="form-label">ملاحظات</label><textarea class="form-textarea" name="notes" rows="2"></textarea></div>
        <button type="submit" class="btn btn-accent" style="width:100%">إضافة الأستاذ</button>
      </form>
    `;
    Modal.open({ title: 'إضافة أستاذ جديد', content, size: 'lg' });
  }

  async function submitAdd(e) {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(e.target));
    try {
      await API.post('/admin/teachers', body);
      Modal.close();
      Toast.success('تم إضافة الأستاذ بنجاح');
      loadTeachers();
    } catch (err) { Toast.error(err.message); }
  }

  async function viewTeacher(id) {
    try {
      const data = await API.get(`/admin/teachers/${id}`);
      const t = data.teacher;
      const content = `
        <div style="font-size:0.88rem;line-height:2">
          <div><strong>الاسم:</strong> ${t.full_name}</div>
          <div><strong>المادة:</strong> ${t.subject || '—'}</div>
          <div><strong>البريد:</strong> ${t.email}</div>
          <div><strong>الهاتف:</strong> ${t.phone || '—'}</div>
          <div><strong>عدد الدورات:</strong> ${data.courses.length}</div>
          <div><strong>عدد التلاميذ:</strong> ${data.students_count}</div>
        </div>
        ${data.courses.length > 0 ? `
          <h4 style="margin-top:16px;margin-bottom:8px">الدورات</h4>
          ${data.courses.map(c => `<span class="badge badge-info" style="margin:2px">${c.name} (${c.level})</span>`).join('')}
        ` : ''}
      `;
      Modal.open({ title: t.full_name, content, size: 'md' });
    } catch (err) { Toast.error(err.message); }
  }

  async function editTeacher(id) {
    try {
      const data = await API.get(`/admin/teachers/${id}`);
      const t = data.teacher;
      const content = `
        <form onsubmit="AdminTeachers.submitEdit(event, '${id}')">
          <div class="form-row">
            <div class="form-group"><label class="form-label">الاسم</label><input type="text" class="form-input" name="full_name" value="${t.full_name}" required></div>
            <div class="form-group"><label class="form-label">المادة</label><input type="text" class="form-input" name="subject" value="${t.subject || ''}"></div>
          </div>
          <div class="form-row">
            <div class="form-group"><label class="form-label">البريد</label><input type="email" class="form-input" name="email" value="${t.email}" required></div>
            <div class="form-group"><label class="form-label">الهاتف</label><input type="tel" class="form-input" name="phone" value="${t.phone || ''}"></div>
          </div>
          <div class="form-group"><label class="form-label">كلمة مرور جديدة (اتركها فارغة إن لم تُرد تغييرها)</label><input type="password" class="form-input" name="password"></div>
          <button type="submit" class="btn btn-primary" style="width:100%">حفظ</button>
        </form>
      `;
      Modal.open({ title: `تعديل ${t.full_name}`, content, size: 'md' });
    } catch (err) { Toast.error(err.message); }
  }

  async function submitEdit(e, id) {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(e.target));
    if (!body.password) delete body.password;
    try {
      await API.put(`/admin/teachers/${id}`, body);
      Modal.close();
      Toast.success('تم التحديث');
      loadTeachers();
    } catch (err) { Toast.error(err.message); }
  }

  async function impersonate(id) {
    try {
      const data = await API.post(`/admin/teachers/${id}/impersonate`);
      Auth.startImpersonation(data.impersonation_token);
      window.location.hash = '#/teacher/dashboard';
      window.location.reload();
    } catch (err) { Toast.error(err.message); }
  }

  async function deleteTeacher(id) {
    const confirmed = await Modal.confirm({ title: 'حذف الأستاذ', message: 'هل أنت متأكد؟', confirmText: 'حذف' });
    if (!confirmed) return;
    try { await API.delete(`/admin/teachers/${id}`); Toast.success('تم الحذف'); loadTeachers(); }
    catch (err) { Toast.error(err.message); }
  }

  return { render, showAddModal, submitAdd, viewTeacher, editTeacher, submitEdit, impersonate, deleteTeacher };
})();
